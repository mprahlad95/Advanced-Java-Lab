import java.rmi.*;
	public class AddClient {
		public static void main(String args[]) {
		try	{
			String addServerURL = "rmi://" + args[0] + "/AddServer";
			AddServerIntf addServerIntf =(AddServerIntf)Naming.lookup(addServerURL);
			System.out.println("The first string is: " + args[1]);
			String s1 = String.valueOf(args[1]);
			System.out.println("The second string is: " + args[2]);
			String s2 = String.valueOf(args[2]);
			System.out.println("Result of concatenation: " + addServerIntf.concatString(s1, s2));	
			System.out.println("Length of String 1: " + addServerIntf.lengthString(s1));
			System.out.println("Length of String 2: " + addServerIntf.lengthString(s2));	
			System.out.println("Uppercase: " + addServerIntf.upperCaseString(s1));	
			System.out.println("Lowercase: " + addServerIntf.lowerCaseString(s2));	
			System.out.println("Result of comparision " + addServerIntf.compareString(s1, s2));	
					
			}
		catch(Exception e)
		{
			System.out.println("Exception: " + e);
		}
	}
}
