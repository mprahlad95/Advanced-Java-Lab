import java.rmi.*;
	public class AddClient {
		public static void main(String args[]) {
		try	{
			String addServerURL = "rmi://" + args[0] + "/AddServer";
			AddServerIntf addServerIntf =(AddServerIntf)Naming.lookup(addServerURL);
			System.out.println("The first number is: " + args[1]);
			double d1 = Double.valueOf(args[1]).doubleValue();
			System.out.println("The second number is: " + args[2]);
			double d2 = Double.valueOf(args[2]).doubleValue();
			System.out.println("Result of addition: " + addServerIntf.add(d1, d2));	
			System.out.println("Result of subtraction: " + addServerIntf.subtract(d1, d2));
			System.out.println("Result of multiplication: " + addServerIntf.multiply(d1, d2));
			System.out.println("Result of division: " + addServerIntf.divide(d1, d2));
			System.out.println("Sin of first number: " + addServerIntf.sin(d1));
			System.out.println("Sin of second number: " + addServerIntf.sin(d2));
			System.out.println("Cos of first number: " + addServerIntf.cos(d1));
			System.out.println("Cos of second number: " + addServerIntf.cos(d2));
			}
		catch(Exception e)
		{
			System.out.println("Exception: " + e);
		}
	}
}
